package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"

	_ "github.com/lib/pq"
)

// ====== database configuration ===== //

var db *sql.DB

type DBConfig struct {
	Host     string `json:"host"`
	Port     int    `json:"port"`
	User     string `json:"user"`
	Password string `json:"password"`
	DBName   string `json:"dbname"`
	SSLMode  string `json:"sslmode"`
}


func loadDBConfig(path string) (*DBConfig, error) {
	fmt.Println("loadDBConfig started")
	file, err := ioutil.ReadFile(path)
	fmt.Println("file : ",file)
	if err != nil {
		return nil, err
	}

	var config DBConfig
	err = json.Unmarshal(file, &config)
	if err != nil {
		return nil, err
	}
	fmt.Println("config : ",config)
	return &config, nil
}


func initDB(config *DBConfig) {
	fmt.Println("initDB started")
	var err error
	connStr := fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=%s",
		config.Host, config.Port, config.User, config.Password, config.DBName, config.SSLMode)

	db, err = sql.Open("postgres", connStr)
	if err != nil {
		log.Fatal("Error connecting to DB:", err)
	}
	if err = db.Ping(); err != nil {
		log.Fatal("DB ping failed:", err)
	}

	fmt.Println("Connected to PostgreSQL database successfully")
}


// =================================== //