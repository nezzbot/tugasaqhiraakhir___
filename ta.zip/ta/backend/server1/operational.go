package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
)

// ==== operational ====== //
type RequestData struct {
	N  string `json:"n"`
	R1 string `json:"r1"`
}

type Result struct {
	R2 string
	Salt string
	Iteration int
}

func server_first(w http.ResponseWriter, r *http.Request) {
	
	fmt.Println("handlePost has started operating")
	if r.Method != http.MethodPost {
		http.Error(w, "Only POST method is allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "Error reading body", http.StatusBadRequest)
		return
	}
	defer r.Body.Close()

	var param RequestData
	if err := json.Unmarshal(body, &param); err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	fmt.Println("Received POST param: ",param)

	fmt.Println("n (user login name):", param.N)
	fmt.Println("r1 (nonce1):", param.R1)

	name := param.N
	nonce1 := param.R1
	r2 := nonce1+GenerateRandomString(8)
	fmt.Println("r2 (nonce2):", r2)

	
	// ========= database =========== //
	query := `SELECT id, login_name, salt, iteration FROM login_info WHERE login_name = $1`
	fmt.Println("query : ",query)
	row := db.QueryRow(query, name)


	var (
		id        string
		loginName string
		salt      string
		iteration int
	)

	err = row.Scan(&id, &loginName, &salt, &iteration)
	if err != nil {
		if err == sql.ErrNoRows {
			fmt.Println("User not found")
		} else {
			fmt.Println("DB error:", err)
		}
		return
	}

	fmt.Println("Found user: ID=%d, Name=%s, Salt=%s, Iteration=%d\n", id, loginName, salt, iteration)
	result := Result{
		R2:        r2,
		Salt:      salt,
		Iteration: iteration,
	}
	
	jsonResult, err := json.Marshal(result)
	if err != nil {
		http.Error(w, "Failed to encode JSON", http.StatusInternalServerError)
		return
	}
	// ============================== //

	// ======== return ============= //
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(jsonResult)
	// ============================= //
}
