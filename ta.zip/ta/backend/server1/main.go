package main

import (
	"fmt"
	"log"
	"net/http"

	_ "github.com/lib/pq"
)


func main() {
	config, err := loadDBConfig("config.json")
	if err != nil {
		log.Fatal("Failed to load DB config:", err)
	}
	initDB(config)

	http.HandleFunc("/submit", server_first)

	fmt.Println("Server running on http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
