package main

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"math/rand"
	"time"

	"golang.org/x/crypto/pbkdf2"
)

// =========== lib start ============= //


const charset = "abcdefghijklmnopqrstuvwxyz0123456789"

// generate random string
func GenerateRandomString(length int) string {
	seededRand := rand.New(rand.NewSource(time.Now().UnixNano()))
	result := make([]byte, length)

	for i := range result {
		result[i] = charset[seededRand.Intn(len(charset))]
	}

	return string(result)
}

// PBKDF2_SHA256 generates a derived key using PBKDF2 with SHA-256
func PBKDF2_SHA256(password, salt string, iterations, keyLen int) string {
	key := pbkdf2.Key([]byte(password), []byte(salt), iterations, keyLen, sha256.New)
	return hex.EncodeToString(key)
}

// GenerateHmacHex creates an HMAC-SHA256 hex string from the message and key
func GenerateHmacHex(message, key, notif string) string {
	fmt.Println("This is", notif, "operation")
	fmt.Println("Key:", key)
	fmt.Println("Message:", message)

	if message == "" || key == "" {
		fmt.Println("Message or key not provided.")
		return ""
	}

	h := hmac.New(sha256.New, []byte(key))
	h.Write([]byte(message))
	hash := h.Sum(nil)
	result := hex.EncodeToString(hash)

	fmt.Println(notif, ":", result)
	return result
}


// GenerateHmacBase64 creates an HMAC-SHA256 Base64 string from the message and key
func GenerateHmacBase64(message, key, notif string) string {
	fmt.Println("This is", notif, "operation")
	fmt.Println("Key:", key)
	fmt.Println("Message:", message)

	if message == "" || key == "" {
		fmt.Println("Message or key not provided.")
		return ""
	}

	h := hmac.New(sha256.New, []byte(key))
	h.Write([]byte(message))
	hash := h.Sum(nil)
	result := base64.StdEncoding.EncodeToString(hash)

	fmt.Println(notif, ":", result)
	return result
}
// =========== lib end ============= //