const app = Vue.createApp({
    data() {
      return {
        username: '',
        password: '',
        r1: null,
        r2: null,
        s: null,
        i: null,
        p: null,
        v: null,
        r3: null,
        r4: null,
        session_id: null,
        showPassword: false,
      };
    },
    methods: {
      // ======== lib start ========== //
      generateRandomString(length) {
        const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
          const randomIndex = Math.floor(Math.random() * characters.length);
          result += characters[randomIndex];
        }
        return result;
      },
  
      generateHmac_64(message, key, notif) {
        console.log("this is ", notif, " operation");
        console.log("key: ", key);
        console.log("message: ", message);
        if (message && key) {
          const hmac = CryptoJS.HmacSHA256(message, key);
          const res = CryptoJS.enc.Base64.stringify(hmac);
          console.log(notif, " : ", res);
          return res;
        } else {
          console.error("Message or key not provided.");
          return null;
        }
      },
  
      generateHmac_hex(message, key, notif) {
        console.log("this is ", notif, " operation");
        console.log("key: ", key);
        console.log("message: ", message);
        if (message && key) {
          const hmac = CryptoJS.HmacSHA256(message, key);
          const res = CryptoJS.enc.Hex.stringify(hmac);
          console.log(notif, " : ", res);
          return res;
        } else {
          console.error("Message or key not provided.");
          return null;
        }
      },
  
      async PBKDF2_SHA256(password, salt, iterations) {
        const enc = new TextEncoder();
        const keyMaterial = await window.crypto.subtle.importKey(
          'raw',
          enc.encode(password),
          { name: 'PBKDF2' },
          false,
          ['deriveKey']
        );
  
        const key = await window.crypto.subtle.deriveKey(
          {
            name: 'PBKDF2',
            salt: enc.encode(salt),
            iterations: iterations,
            hash: "SHA-256",
          },
          keyMaterial,
          {
            name: 'AES-CBC',
            length: 256,
          },
          true,
          ['encrypt', 'decrypt']
        );
  
        const rawKey = await window.crypto.subtle.exportKey('raw', key);
        const hexKey = Array.from(new Uint8Array(rawKey)).map(b => b.toString(16).padStart(2, '0')).join('');
        return hexKey;
      },
      // ======== lib end ========== //
  
      // ======= operational start =========== //
      async clientFirst() {
        console.log("client first operation start !!");
        this.r1 = this.generateRandomString(8);
  
        try {
          const postData = {
            username: this.username,
            r1: this.r1,
          };
          console.log("Sending JSON:", JSON.stringify(postData));
  
          const response = await axios.post(FIRST_SERVER + '/login', postData);
          const data = response.data;
          console.log("data from backend : ", data);
  
          this.r2 = data.r2;
          this.s = data.s;
          this.i = data.i;
  
          return true;
        } catch (error) {
          console.error('Failed to submit username and half_nonce:', error.response ? error.response.data : error.message);
          return false;
        }
      },
  
      async clientFinal() {
        console.log("client final operation start !!");
        try {
          const postData = {
            r2: this.r2,
            p: this.p,
            r3: this.generateRandomString(8),
          };
          console.log("Sending JSON:", JSON.stringify(postData));
  
          const response = await axios.post(SECOND_SERVER + '/challenge_proof', postData);
          const data = response.data;
  
          this.session_id = data.session_id;
          this.r4 = data.r4;
          this.user_data = data.user_data;
        } catch (error) {
          console.error('Failed to send data back:', error.response ? error.response.data : error.message);
        }
      },
      // ======= operational end =========== //
  
      // ====== executing order start ======== //
      async handleSubmit() {
        // implement logic if needed
      },
      // ====== executing order end ======== //
    },
  });
  
  app.mount('#app');
  