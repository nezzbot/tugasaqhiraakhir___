// Define the base URL for your API
const FIRST_SERVER = 'https://';
const SECOND_SERVER = 'https://';



// Define the URL for redirection


// Expose the variables and functions globally
window.FIRST_SERVER = FIRST_SERVER;
window.SECOND_SERVER = SECOND_SERVER;
